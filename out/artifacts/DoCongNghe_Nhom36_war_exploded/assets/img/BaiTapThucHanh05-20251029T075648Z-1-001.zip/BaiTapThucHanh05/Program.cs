﻿using ConsoleApp1;
using System;
using System.Collections.Generic;
using System.Text;

internal class Program
{
    private static void Main(string[] args)
    {
        Console.InputEncoding = Encoding.UTF8;
        Console.OutputEncoding = Encoding.UTF8;

        var dao = new StudentDAO();

        while (true)
        {
            ShowMenu();
            Console.Write("Chọn chức năng: ");
            var choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    {
                        Console.WriteLine("\n=== DANH SÁCH SINH VIÊN ===");
                        var list = dao.getAllStudents();
                        dao.PrintListStudents(list);
                        Console.WriteLine("===========================\n");
                        break;
                    }
                case "2":
                    {
                        int id = ReadInt("Nhập ID sinh viên cần tìm: ");
                        var st = dao.getStudentById(id);
                        if (st != null)
                        {
                            Console.WriteLine("Tìm thấy: " + st);
                        }
                        else
                        {
                            Console.WriteLine("Không tìm thấy sinh viên có ID = " + id);
                        }
                        Console.WriteLine();
                        break;
                    }
                case "3":
                    {
                        Console.WriteLine("\n=== THÊM SINH VIÊN MỚI ===");
                        int id = ReadInt("ID: ");
                        string name = ReadNonEmpty("Họ tên: ");
                        double score = ReadScore("Điểm trung bình (0..10): ");
                        var st = new Student(id, name, score);
                        bool ok = dao.insertStudent(st);
                        Console.WriteLine(ok ? "Thêm thành công." : "Thêm thất bại.");
                        Console.WriteLine();
                        break;
                    }
                case "4":
                    {
                        Console.WriteLine("\n=== CẬP NHẬT SINH VIÊN ===");
                        int id = ReadInt("Nhập ID cần cập nhật: ");
                        var exist = dao.getStudentById(id);
                        if (exist == null)
                        {
                            Console.WriteLine("Không tồn tại sinh viên ID = " + id + "\n");
                            break;
                        }
                        Console.WriteLine("Hiện tại: " + exist);

                        string name = ReadNonEmpty("Họ tên (mới): ");
                        double score = ReadScore("Điểm TB (mới, 0..10): ");

                        var st = new Student(id, name, score);
                        bool ok = dao.updateStudent(st);
                        Console.WriteLine(ok ? "Cập nhật thành công." : "Cập nhật thất bại.");
                        Console.WriteLine();
                        break;
                    }
                case "5":
                    {
                        Console.WriteLine("\n=== XÓA SINH VIÊN ===");
                        int id = ReadInt("Nhập ID cần xóa: ");
                        var exist = dao.getStudentById(id);
                        if (exist == null)
                        {
                            Console.WriteLine("Không tồn tại sinh viên ID = " + id + "\n");
                            break;
                        }
                        Console.Write("Xác nhận xóa (y/n)? ");
                        var confirm = Console.ReadLine()?.Trim().ToLower();
                        if (confirm == "y" || confirm == "yes")
                        {
                            bool ok = dao.deleteStudent(id);
                            Console.WriteLine(ok ? "Xóa thành công." : "Xóa thất bại.");
                        }
                        else
                        {
                            Console.WriteLine("Đã hủy xóa.");
                        }
                        Console.WriteLine();
                        break;
                    }
                case "0":
                    {
                        Console.WriteLine("Thoát chương trình. Tạm biệt!");
                        return;
                    }
                default:
                    {
                        Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng nhập 0..5.\n");
                        break;
                    }
            }
        }
    }

    static void ShowMenu()
    {
        Console.WriteLine("==== MENU ====");
        Console.WriteLine("1. Xem danh sách sinh viên");
        Console.WriteLine("2. Tìm sinh viên theo ID");
        Console.WriteLine("3. Thêm sinh viên mới");
        Console.WriteLine("4. Cập nhật sinh viên");
        Console.WriteLine("5. Xóa sinh viên");
        Console.WriteLine("0. Thoát");
    }

    // Helpers nhập liệu an toàn
    static int ReadInt(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            var s = Console.ReadLine();
            if (int.TryParse(s, out int v)) return v;
            Console.WriteLine("⚠ Vui lòng nhập số nguyên hợp lệ!");
        }
    }

    static double ReadScore(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            var s = Console.ReadLine();
            if (double.TryParse(s, out double v) && v >= 0 && v <= 10) return v;
            Console.WriteLine("⚠ Điểm phải là số trong khoảng 0..10!");
        }
    }

    static string ReadNonEmpty(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            var s = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(s)) return s.Trim();
            Console.WriteLine("⚠ Trường này là bắt buộc!");
        }
    }
}
