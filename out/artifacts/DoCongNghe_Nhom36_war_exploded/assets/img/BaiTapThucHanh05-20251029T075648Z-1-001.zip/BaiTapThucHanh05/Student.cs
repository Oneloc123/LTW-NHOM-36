﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
     class Student
    {
        public int id_student { get; set; }
        public String full_name { get; set; }
        public double avg_score { get; set; }

        public Student(int id_student, String full_name, double avg_score)
        {
            this.id_student = id_student;
            this.full_name = full_name;
            this.avg_score = avg_score;
        }

        public override String ToString()
        {
            return id_student + "---" + full_name + "---" + avg_score;
        }
    }
 
    
}
