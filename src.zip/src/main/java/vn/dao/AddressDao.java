package vn.dao;

import vn.model.Address;

public class AddressDao extends BaseDao{

    public void updateAddressByid(int id, String addressModal) {

    }

    public Address getAddressById(int id) {

        return null;
    }
}
