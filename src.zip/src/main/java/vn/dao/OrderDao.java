package vn.dao;

import vn.model.Order;

import java.util.List;

public class OrderDao extends BaseDao{
    public List<Order> getListOrderById(int id){
        return null;
    }
}
