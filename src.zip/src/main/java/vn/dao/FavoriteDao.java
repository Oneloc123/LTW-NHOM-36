package vn.dao;

public class FavoriteDao {
}
