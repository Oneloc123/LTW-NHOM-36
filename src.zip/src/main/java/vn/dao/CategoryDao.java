package vn.dao;

public class CategoryDao {
}
