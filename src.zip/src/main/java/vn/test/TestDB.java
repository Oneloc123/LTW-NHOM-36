package vn.test;

import vn.dao.ContactDao;

public class TestDB {
}