package vn.services;

public class CheckoutService {

    public boolean processCheckout() {
        // Demo thanh toán thành công
        return true;
    }
}
