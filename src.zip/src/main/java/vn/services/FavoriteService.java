package vn.services;

public class FavoriteService {
}
