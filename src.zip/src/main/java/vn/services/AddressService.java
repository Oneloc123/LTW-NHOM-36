package vn.services;

import vn.dao.AddressDao;
import vn.model.Address;

public class AddressService {
    AddressDao addressDao;
    public void updateAdress(int id,String addressModal) {
        addressDao.updateAddressByid(id,addressModal);
    }

    public Address getAddressById(int id) {
        return addressDao.getAddressById(id);
    }
}
