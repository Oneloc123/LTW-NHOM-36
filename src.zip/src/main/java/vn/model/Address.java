package vn.model;

public class Address {
}
