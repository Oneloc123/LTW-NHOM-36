package vn.model;

public class FavoriteProduct {
}
