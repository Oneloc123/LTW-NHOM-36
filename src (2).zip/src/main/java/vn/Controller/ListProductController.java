package vn.Controller;

import java.io.*;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import vn.model.Product;
import vn.services.ProductService;

@WebServlet("/products")
public class ListProductController extends HttpServlet {

    private ProductService ps = new ProductService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        List<Product> list = ps.getListProduct();
        req.setAttribute("list", list);
        req.getRequestDispatcher("/pages/products.jsp")
                .forward(req, resp);
    }
}