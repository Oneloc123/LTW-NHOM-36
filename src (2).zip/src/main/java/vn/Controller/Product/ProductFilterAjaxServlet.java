package vn.Controller.Product;

import com.google.gson.Gson;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import vn.dao.ProductDao;
import vn.model.Product;

import java.io.IOException;
import java.util.List;

@WebServlet("/products/filter")
public class ProductFilterAjaxServlet extends HttpServlet {

    private final ProductDao productDao = new ProductDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json;charset=UTF-8");

        String keyword = req.getParameter("keyword");
        String sort = req.getParameter("sort");

        Integer categoryId = parseInt(req.getParameter("category"));
        Integer minPrice = parseInt(req.getParameter("minPrice"));
        Integer maxPrice = parseInt(req.getParameter("maxPrice"));

        List<Product> list = productDao.filterAjax(keyword, categoryId, minPrice, maxPrice, sort);

        Gson gson = new Gson();
        resp.getWriter().write(gson.toJson(list));
    }

    private Integer parseInt(String v) {
        try {
            return (v == null || v.isBlank()) ? null : Integer.parseInt(v);
        } catch (Exception e) {
            return null;
        }
    }
}
